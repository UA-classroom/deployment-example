import React from "react";

export default function DashboardIndexPage() {
  return (
    <div className="min-w-xl">
      <div className="min-h-screen my-8 bg-white border border-gray-200 shadow-md">
        {/* Course List */}
        <div className="p-6"></div>
      </div>
    </div>
  );
}
